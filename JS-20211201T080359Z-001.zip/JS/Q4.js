let str1 = "What I'd like to tell on this topic is:";
let str2 = "Hi everyone!";
let maxlength = 20;

function truncate(str, maxlength){
    if(str.length <= maxlength){
        return str;
    } else {
        let strArray = Array.from(str);
        strArray.splice(maxlength - 1);
        strArray.push('...');
        let newStr = strArray.join("");
        return newStr;
    }
}

console.log(truncate(str1, maxlength));
console.log(truncate(str2, maxlength));