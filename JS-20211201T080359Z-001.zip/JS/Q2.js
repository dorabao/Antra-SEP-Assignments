let menu = {
    width: 200,
    height: 300,
    title: "My menu"
};


function multiplyNumeric(obj){
    for(let prop of Object.keys(obj)){
        if( typeof obj[prop] == "number") {
            obj[prop] = obj[prop] * 2;
        }
    }
}

multiplyNumeric(menu);
console.log(menu);