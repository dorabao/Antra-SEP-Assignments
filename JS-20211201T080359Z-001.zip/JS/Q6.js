function luhnCheck(cardNum){
    let sum = 0;
    let array = Array.from(cardNum);
    let lastDigit = array.pop();
    for(let num of array){
        sum += num * 2;
    }
    return sum % 10 == lastDigit;
}
function chipCheck(cardNum, bannedPrefixes){
    let bannedList = bannedPrefixes.split(',');
    for(let prefix of bannedList){
        if(cardNum.startsWith(prefix)){
            return false;
        }
    }
    return true;
}

function cardsToValidate(cardNum, bannedPrefixes){
    let result = {
        card: cardNum,
        isValid: luhnCheck(cardNum),
        isAllowed: chipCheck(cardNum, bannedPrefixes)
    }
    return JSON.stringify(result);
}

var cardNum = "6724843711060148";
var bannedPrefixes = "11,3434,67453,9";

console.log(cardsToValidate(cardNum, bannedPrefixes));