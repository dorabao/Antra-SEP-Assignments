/*Write a function that takes in an array of integers and returns the length of the longest peak in the array.
A peak is defined as adjacent integers in the array that are stricly increasing 
until they reach a tip (the highest value in the peak), at which point they become strictly decreasing. 
At least three integers are required to form a peak. 
*/

function longestPeak(array) {
    let length = array.length;
    let result = 0;
    let start = 0;
    while (start < length) {
        let end = start;
        if (end + 1 < length && array[end] < array[end + 1]) {
            while (end + 1 < length && array[end] < array[end + 1]) {
                end++;
            }
            if (end + 1 < length && array[end] > array[end + 1]) {
                while (end + 1 < length && array[end] > array[end + 1]) {
                    end++;
                }
                result = Math.max(result, end - start + 1);
            }
        }
        start = Math.max(end, start + 1);
    }
    return result;
}

var array1 = [1,2,3,3,4,0,10,6,5,-1,-3,2,3];
var array2 = [1,3,2];
var array3 = [5,4,3,2,1,2,1];

console.log(longestPeak(array1));
console.log(longestPeak(array2));
console.log(longestPeak(array3));
