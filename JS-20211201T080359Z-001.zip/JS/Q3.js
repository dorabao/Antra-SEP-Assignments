let email1 = "dorriebao@gmail.com";
let email2 = "dorriebao.come@gmail";

function checkEmailId(str) {
    for(let i = 0; i < str.length; i++){
        if(str.charAt(i) == '@'){
            var index1 = i;
        } else if(str.charAt(i) == '.'){
            var index2 = i;
        }
    }
    if(index1 + 1 < index2) return true;
    else return false;
}

console.log(checkEmailId(email1));
console.log(checkEmailId(email2));