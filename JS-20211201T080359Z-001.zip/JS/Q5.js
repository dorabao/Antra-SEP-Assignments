var array = new Array("James", "Brennie");
array.push("Robert");
array.splice(array.length / 2, 1, "Calvein");
array.shift();
array.unshift("Rose", "Regal");
console.log(array);