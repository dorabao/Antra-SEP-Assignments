let salaries = {
    John: 100,
    Ann: 160,
    Pete: 130
}

function sumSalaries(salaries){
    let result = 0;
    for(let i of Object.values(salaries)){
        result += i;
    }
    return result;
}

console.log(sumSalaries(salaries));